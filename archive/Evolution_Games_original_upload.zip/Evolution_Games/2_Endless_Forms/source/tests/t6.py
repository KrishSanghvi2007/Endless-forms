from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':390,'height':780})
    pg.goto('file:///home/claude/ef/Endless_Forms_v1.html'); pg.wait_for_timeout(900)
    r=pg.evaluate("""()=>{ const out=[]; const C=TB.REG.castaways;
      for(const pol of [0,15,12,8]) { const res=[]; let alive=0; for(let s=0;s<10;s++){ TB.seed(70+s*11); TB.Cards.close(); TB.App.play(C); C.lv=1; C.begin2(); let g=0; const w=[];
        while(!C.over && g++<200){ if(pol && C.gen%pol===Math.floor(pol/2)) C.migrant(); C.acc=2; C.update(0.01); if(C.gen%10===0) w.push(+C.log.at(-1).w.toFixed(2)); }
        const s2=C.log.at(-1); if(C.gen>=60&&s2.n>0) alive++; res.push(C.gen+'/'+C.mig+'/'+w.slice(0,7).join(',')); }
        out.push('every '+pol+': alive '+alive+'/10   '+res.slice(0,4).join('  ')); }
      return out; }""")
    print('\n'.join(r)); b.close()
