ENDLESS FORMS ATLAS — macOS (Apple Silicon & Intel, fully offline)
====================================================================

25 interactive 3D plates / 150 pages. No install, no internet needed.

OPTION A — quickest (no security prompt)
  Double-click  Endless_Forms_Atlas.html
  It opens in Safari / Chrome / Firefox / Edge.

OPTION B — as a Mac app with its own icon
  1. Drag  "Endless Forms Atlas.app"  into your Applications folder.
  2. First launch only: right-click (Control-click) the app -> Open -> Open.
     (The app is unsigned open-source software, so macOS asks once.)
  3. After that, launch it normally from Launchpad / Spotlight / the Dock.

If macOS says the app "is damaged" or "can't be opened", run once in Terminal:
  xattr -dr com.apple.quarantine "/Applications/Endless Forms Atlas.app"
or simply use Option A.

Tip: WebGL works best in an up-to-date Safari or Chrome.
